
function compararNumeros(){
    var numero1=parseFloat(prompt("Digite o primeiro número"));
    var numero2=parseFloat(prompt("Digite o segundo número"));
    var soma=numero1+numero2;
    alert(`A soma dos números digitados é:\n${soma}`);   
}